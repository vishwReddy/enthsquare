var products = [
  {
    "product_category": "kitchen",
    "product_name": "4-Piece Set Bamboo Table Matt"
  },
  {
    "product_category": "kitchen",
    "product_name": "Expresso Coffee Maker"
  },
  {
    "product_category": "shoes",
    "product_name": "Puma Trainers x3"
  },
  {
    "product_category": "home",
    "product_name": "4x6 Photo Frame"
  },
  {
    "product_category": "shoes",
    "product_name": "Skechers ProWalkers"
  },
  {
    "product_category": "home",
    "product_name": "Shower Curtain"
  },
  {
    "product_category": "home",
    "product_name": "Accent Table Lamp"
  },
  {
    "product_category": "electronics",
    "product_name": "Cannon x930 DSLR Camera"
  },
  {
    "product_category": "kitchen",
    "product_name": "12 Qt Pressure Cooker"
  },
  {
    "product_category": "electronics",
    "product_name": "Apple Iphone 8"
  },
  {
    "product_category": "kitchen",
    "product_name": "Wooden Hexagonal Coasters"
  },
  {
    "product_category": "electronics",
    "product_name": "Bose QC 300 Headphones"
  },
  {
    "product_category": "shoes",
    "product_name": "Reebok Classic 1990"
  },
  {
    "product_category": "kitchen",
    "product_name": "12-Piece Knife Set"
  },
  {
    "product_category": "shoes",
    "product_name": "Nike Air Max Elite"
  },
  {
    "product_category": "home",
    "product_name": "100% Cotton Towels"
  },
  {
    "product_category": "electronics",
    "product_name": "Sony Super Bass Earbuds"
  },
  {
    "product_category": "shoes",
    "product_name": "Addidas Foamfits"
  }
];





 var output= '';
	for(var i=0; i < products.length; i++){
		//console.log(products[i].name)
		output += '<li>' + products[i].name + '</li>';
	}   
	document.getElementById('products').innerHTML = output;






